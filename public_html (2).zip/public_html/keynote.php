<?php
include 'main.php';
mywebhead();
?>
        <!--MAin content-->
             
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <h2><center>Keynote Speakers</center><br><br></h2> 
	 	       </div>
	 	       
	 	       
	 	       <!--
	 	       <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center> <br><img  class="bg1 img2"  src="/images/shri.paneerselvam.jpg" width=200em></img>
        	 	     <br></div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Shri R. Panneer Selvam</h3>
                      <h4 style="text-indent:0em"><center>MSME Technology Development Centre<br>
(Process and Product Development Centre)<br>
Ministry of Micro, Small &amp; Medium Enterprises (MSME)<br>
Govt. of  India.<br>
                      </h4>
                      </div>
              </div>
              <!--
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center> <img  class="bg1" src="/images/Dr.ManpreetSinghManna.jpg" width=200pt></img>
        	 	     </div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Dr. Manpreet Singh Manna</h3>
                      <h4 style="text-indent:0em">
                       <center>Sant Longowal Institute of Engineering & Technology, Punjab, India.
                        <br> Former Director, AICTE, Ministry of Education, Govt. of India.
                        <br> Member, United Nation Organization SDG4.
                      </h4>
                      </div>
              </div>
              
               <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12 ">
                 <center><br> <img class="bg1 img2" src="images/ColBVenkat.webp" width="202 em" height="200 em"></img>
        	 	<br> </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 " style="valign='center';">
                 <h3><br> <center> Col. B Venkat</h3>
                 <h4 style="text-indent:0em"><center>
                     Director (Faculty Development), AICTE.
</h4>
	 	         </div>    
	 	       </div>
              -->
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12 ">
                 <center><br> <img class="bg1 img2" src="images/Dr.Shrishail.webp" width="202 em" height="200 em"></img>
        	 	<br> <br></div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 " style="valign='center';">
                 <h3><br> <center> Dr. Shrishail Kamble</h3>
                 <h4 style="text-indent:0em"><center>
                     Assistant Director,
                     <br> Institutional Development Cell
 <br>All India Council for Technical Education (AICTE),
<br>Ministry of Education, New Delhi, India. <br><br>
</h4>
	 	         </div>    
	 	       </div>
	 	       
	 	       
	 	       <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center> <img  class="bg1 img2" src="/images/Dr.ManpreetSinghManna.jpg" width=200pt></img>
        	 	    <br> </div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Dr. Manpreet Singh Manna</h3>
                      <h4 style="text-indent:0em">
                       <center>Sant Longowal Institute of Engineering & Technology, Punjab, India.
                        <br> Former Director, AICTE, Ministry of Education, Govt. of India.
                        <br> Member, United Nation Organization SDG4.
                      </h4>
                      </div>
              </div>
	 	       
	 	       <!--
	 	        <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center> <br><img  class="bg1 img2" src="images/Dr.Lance.webp" width="200 em"></img>
        	 	     <br></div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Dr. Lance Chun Che Fung</h3>
                      <h4 style="text-indent:0em"><center>Murdoch University, Australia<br>
                      IEEE Region 10 Director
                      </h4>
                      </div>
              </div> -->
              
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center><br> <img  class="bg1 img2" src="images/Dr.Chennupati.webp" width="200 em"></img>
        	 	     <br></div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Dr. Chennupati Jagadish</h3>
                      <h4 style="text-indent:0em"><center>Australian National University, Australia
                      <br>IEEE Photonics Society President 2018 - 2019
                      </h4>
                      </div>
              </div>
              
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center><br> <img  class="bg1 img2" src="/images/Prof. Wladyslaw Grabinski.jpg" width="200 em"></img><br>
        	 	     </div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Prof. Wladyslaw Grabinski</h3>
                      <h4 style="text-indent:0em"><center>MOS AK Association,<br>
                      <center>Switzerland.</h4>
                      </div>
              </div>
              
              
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center><br> <img  class="bg1 img2" src="/images/Dr.Yong.jpg" width="200 em"></img><br>
        	 	     </div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Prof. Yong Zhang</h3>
                      <h4 style="text-indent:0em"><center>University of Electronic Science and Technology of China,<br>
                      <center>Chengdu, China.</h4>
                      </div>
              </div>
              
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center><br> <img  class="bg1 img2" src="/images/Dr.Unil.jpg" width="200 em"></img><br>
        	 	     </div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Prof. A. G. Unil Perera</h3>
                      <h4 style="text-indent:0em"><center>Georgia State University,<br>
                      <center>Atlanta, USA.</h4>
                      </div>
              </div>
              
              
              
               <!--
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center><br> <img  class="bg1 img2" src="images/Dr.James.webp" width="200 em"></img>
        	 	     <br></div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Dr.James E. Morris</h3>
                      <h4 style="text-indent:0em">
                       <center>Portland State University, USA
                        <br> IEEE Nanotechnology Council President 2020 – 2021
                        
                      </h4>
                      </div>
              </div>
             
              
                   <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12">
                 <center><br> <img class="bg1 img2" src="images/Prof.ShuaiLi.png" width="202 em" height="200 em"></img>
        	 	 <br></div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
                 <h3> <center> Prof. Shuai (Steven) Li</h3>
                 <h4 style="text-indent:0em"><center> Swansea University,<br> United Kingdom.<br></h4>
	 	         </div>    
	 	       </div>
                
	 	       
	 	       
	 	        
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12 ">
                 <center><br> <img class="bg1 img2" src="images/Prof.WalidTawfik.jpg" width="200 em" height="200 em"></img><br>
        	 	 </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 " style="valign='center';">
                 <h3><br> <center> Prof. Walid Tawfik</h3>
                 <h4 style="text-indent:0em"><center> National Institute of Laser Enhanced Sciences (NILES), <br> Cairo University, Giza,<br> Egypt.<br></h4>
	 	         </div>    
	 	       </div>
              
                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12">
                 <center> <br><img class="bg1 img2" src="images/Dr.Maciej.webp" width=" 202 em" height="200 em"></img>
        	 	<br> </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
                 <h3> <center> Dr. Maciej Bazarnink </h3>
                 <h4 style="text-indent:0em"><center> University of Hamburg, Germany</h4>
	 	         </div>    
	 	       </div>
              
	 	       <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 	 	             <div class="col-lg-offset-3 col-lg-3 col-md-offset-3 col-md-3 col-sm-12 col-xs-12">
        	         <center><br> <img  class="bg1 img2" src="images/Dr.Marek.webp" width="200 em"></img>
        	 	     <br></div>
                	 <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
              	      <h3><center>Dr. Marek Nowicki</center></h3>
                      <h4 style="text-indent:0em"><center>Poznań University of Technology, Poland.</h4>
                      </div>
              </div> 
              
              
             
	 	       
	 	       
	 	       <!-- <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12">
                 <center> <img class="bg1" src="images/Srinivas.PNG" width=202pt height=200pt></img>
        	 	 </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
                 <h3> <center> Dr. Srinivas Talabattula</h3>
                 <h4 style="text-indent:0em"><center> Associate Professor - Electrical Communication Engineering,<br>Indian Institute of Science,
 <br> Bengaluru,  Karnataka,<br> India.<br></h4>
	 	         </div>    
	 	       </div>
	 	       
	 	       
              
              <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12 ">
                 <center> <img class="bg1" src="images/Dr.Shyam.webp" width=202pt height=200pt></img>
        	 	 </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 " style="valign='center';">
                 <h3><br> <center> Dr. Shyam K Joshi</h3>
                 <h4 style="text-indent:0em"><center>
                     Vyas Institute of Higher Education
Jodhpur, Rajasthan
</h4>
	 	         </div>    
	 	       </div>
             
                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12">
                 <center> <br><img class="bg1 img2" src="images/Dr.T.SenthilSivaSubramanian.jpg" width="202 em" height="280 em"></img><br>
        	 	 </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='middle';">
                 <h3> <center><br> Prof. T.Senthil Siva Subramanian</h3>
                 <h4 style="text-indent:0em"><center> Sharda Group of Institutions,<br> Agra, Uttar Pradesh,<br> India.<br></h4>
	 	         </div>    
	 	       </div>
	 	       
	 	        
	 	         
	 	       
	 	       
	 	        <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-offset-3 col-lg-3 col-lg-offset-3 col-md-3 col-sm-12 col-xs-12">
                 <center><br> <img class="bg1 img2" src="images/Alex.jpg" width="202 em" height="280 em"></img><br>
        	 	 </div>
        	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="valign='center';">
                 <h3> <center><br> Mr.Alex J Paul</h3>
                 <h4 style="text-indent:0em"><center> Lead Design Engineer, <br>Tech Mahindra,<br> Cochin,<br> India.<br></h4>
	 	         </div>    
	 	       </div>
	 	       
	 	        -->
	 	          <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <br><br>&nbsp;   
	 	       </div>
	 	       
	 	        
	 	        

	 	       



	 	       
	 	       
            </div>
             </div>
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
            
         
        

 <?php
 mywebfoot();
 ?>