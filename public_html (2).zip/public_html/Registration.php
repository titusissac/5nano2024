<?php
include 'main.php';
mywebhead();
?>


            
        <!--MAin content-->
           
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <h2> <center>Registration</center> <br></h2> 
                 </div>
                 
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <h4>
                 Participation is invited from academic institutions, industry, government and non-government organizations, professional societies and associations pursuing research and development in the fields of interest to the IEEE.
<center>
<br><br>Not a IEEE Photonics Society member?
<br><br>Join IEEE Photonics Society: <a href="https://www.ieee.org/membership-catalog/productdetail/showProductDetailPage.html?product=MEMPHO036&refProd=MEMPHO036" target="_blank">
    <br><br><blink>Register Now!</blink>
<br><img class="bg1 img2" width=125em src="./images/qr_ieeephontonics_join.png" style="border-radius:5pt">
</a>

<br><br><br>
</center>
                   
                   The conference registration covers conference proceedings, conference kit, admission to all
                 workshops, coffee breaks, lunch and banquet. The registration doesn't cover accommodation,
                 transportation etc. <br><br>
                
                At least one author of an accepted paper is required to register at the full registration rate. If
                an author has got more than one accepted papers, each paper has also to be registered.<br><br>
                </div>
                
                <style>
                    table, th, td {
                    border: 1px solid red;
                    text-align:center; 
                    font-style:bold; 
                    font-family:georgia,garamond,serif;
 font-size:1em;
                    }
                    
                 </style>
                
               
                
                <center>
                     
                    <table width="70%">
                <tr>
                <td rowspan=2><b>Type of delegates<b>
                </td>
                <td colspan=2><b>Authors <br>(Indian)</b>
                </td>
                 <td colspan=2><b>Authors<br>(Abroad)</b>
                </td>
                <td colspan=2 ><b>Non Authors</b>
                </td>
                </tr>
                
                <tr>
                 
                <td >IEEE <br> (INR)</h4>
                </td>
                <td >Non-IEEE <br>(INR)</h4>
                </td>
                <td >IEEE <br>(USD)</h4>
                </td>
                <td >Non-IEEE<br> (USD)</h4>
                </td>
                <td >Indian<br>(INR)</h4>
                </td>
                <td >Non-Indian<br>(USD)</h4>
                </td>
                    
                </tr>
                
                
                 <tr>
                <td ><b>Professionals</h4>
                </td> 
                <td >9000</h4>
                </td>
                <td >10000</h4>
                </td>
                <td >250</h4>
                </td>
                <td >300</h4>
                </td>
                <td >3000</h4>
                </td>
                <td>200</h4>
                </td>
                
                
                <tr>
                <td ><b>Students</h4>
                </td> 
                <td >7000</h4>
                </td>
                <td >8000</h4>
                </td>
                <td >200</h4>
                </td>
                <td >250</h4>
                </td>
                <td >2000</h4>
                </td>
                <td>100</h4>
                </td>
                    
                </tr>
                </table>
                
                </center>
                
                
                <br><br>
                
                			
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <h4>
                	    It may be ensured that the Remitter's (Participant/Author) name, Easychair Paper-ID
                and the Purpose of remittance (Registration Fees) is clearly mentioned by the Remitter
                in the Funds Transfer Application. Indian Nationals or Students residing in overseas have
                to pay foreign authors' registration rate only.<br><br>
                <//h4>
                
                <h3>Student Registration<h3>
                <h4>Students (UG/PG Students and only Full time Research/PhD Scholars)
                have to submit their scanned copy of the ID card along with the Registration form to avail the
                deduction. When the students are coming for the presentation, they have to produce the
                original Student ID card / IEEE membership Card.<br><br>
                
                IEEE members are requested to upload IEEE membership card / receipt of payment during the registration process if registering under IEEE category.
                <br><br>
Accompanying guest/spouse, if attending, must register under “Non – Authors Category”
<br><br>IEEE Members shall produce evidence of valid current membership at the venue of the Conference. If they fail to do so, they would be required to pay the difference in fees before being allowed to participate at the conference.

                
                <br><br>Once the payment is made, you are required to scan the proof of Bank Draft or NFET/ RTGS
                Receipt or Wire Transfer Receipt and upload the details online using the same username and
                password you had created earlier or through email :<a href="mailto:5nano2k23@gmail.com">5nano2k23@gmail.com</a> <br><br>
                
                
                
              <h3>Refund Policy</h3>
<h4>Conference Fee once paid would not be refunded under any circumstance.</h3>
<h3>
Visa Assistance Letters</h3>
<h4>Once your registration is complete, you can request invitation letter for VISA purposes: please email to:5nano2k22@gmail.com</h4>

<h3>Copyrights</h3>
<h4>Authors who are submitting a paper for inclusion in IEEE Xplore will be provided with the IEEE Electronic Copyright Form (eCF).  Authors who are registered only will be provided with the IEEE Consent and Release Form. These forms allow IEEE the right to use, distribute, publish, exhibit, digitize, broadcast, reproduce and archive, in any format or medium, whether now known or hereafter developed any materials, including written, audio and visual works. One of these forms are required by each speaker in order to present at the conference. 

</h4>


<br>
     <h4>
                If you have any questions or clarifications on registration, please email to:5nano2k23@gmail.com<br>
                
                </h4>
                </div>
                
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3 >Payment:</h3>
                </div>
               
                
                 
                
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <h4 style=" text-indent:0em;">
                <font style="color:red">Note:</font> Participants must bear the bank service charges for the remittance out of their own accounts.  Demand Draft (DD) drawn in favor of &quot; IEEE
Student Branch VISAT Engineering College &quot;, payable at Kottayam. <br><br>The DD should be sent to the following address</h4>


                </div>
                
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3> <center>    Dr. T.D.Subash,     </center><br> </h3>
                <h4 style="text-indent:0em;">
                 <center> 
                Conference Organizing Chair - IEEE 5NANO2023,<br><br> 
                VISAT Engineering College,<br><br>  Elanji, Ernakulam 
                , Kerala, India-686 631.<br><br> <br> 
                <b>Tel:</b> <a href="tel:+91 9447691397">+91 9447691397</a>, <a href="tel:+91 9486881397">+91 9486881397</a>.<br><br>  
                <b>E-mail:</b>  <a href="mailto:5nano2k23@gmail.com">5nano2k23@gmail.com</a>, <a href="mailto:tdsubash2007@gmail.com">tdsubash2007@gmail.com</a> 
                
                
                <a href="mailto:deanresearch@visat.ac.in">deanresearch@visat.ac.in</a>
                <br><br> 
               <b> Website:</b> <a href="https://www.5nano2023.com">https://www.5nano2023.com</a><br><br>  
                 </center>    
                </div>

	 	     
         </div>
       
    <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
       
 <?php
 mywebfoot();
 ?>