<?php
include 'main.php';
mywebhead();
?>
            
        <!--MAin content-->
            
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <h2> <center>Location</center> <br></h2> 
                 </div>
               
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
               <center>
                   <iframe class="col-lg-12 col-md-12 col-sm-12 col-xs-12" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3930.9946244227613!2d76.5557743!3d9.8508171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b07da2c8a8e8271%3A0x8e1ab4fa9ba5b0be!2sVISAT%20Engineering%20College%2C%20Ernakulam!5e0!3m2!1sen!2sin!4v1660752636174!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                   
	           <iframe class="col-lg-12 col-md-12 col-sm-12 col-xs-12" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15732.278213540596!2d76.57433147833741!3d9.675098483073652!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b07d30af7bb9e17%3A0x71fff396fcc1cf97!2sMangalam+College+of+Engineering!5e0!3m2!1sen!2sin!4v1540014246683"  frameborder="0"  height="618" style="border:0" allowfullscreen></iframe>
	           <br><br>
	           </div>
	         <br>  &nbsp;<br>&nbsp;
	   
         </div>
       
    <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
      

<?php
 mywebfoot();
 ?>