<?php
include 'main.php';
mywebhead();
?>


            
        <!--MAin content-->
            
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <h2> <center>Publications</center> <br></h2> 
                 </div>
                 
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h4>Authors wishing to participate at the conference must register individually. Each selected paper requires at least one author to attend the conference for presentatio. Papers not actually presented at the conference shall not be included in the Conference Publications.
                    
                    <b><br>All accepted and presented papers will be submitted for inclusion in IEEE Xplore.</b><br>
                    
                    Based on the scope and quality of the research articles, all accepted papers will be published in any one of the following Journals which is listed below, based on authors concern.
                    </h4>
                 </div>
                    
                <div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                    <h3><center>&bull;</h3>
                </div>
                <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                    <h3>
                    Diamond & Related Materials -  Elsevier (SCI indexed)
                    </h3>
                </div>
                
                <div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                    <h3><center>&bull;</h3>
                </div>
                <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                    <h3>International Journal of Hydrogen Energy -  Elsevier (SCI indexed)
                    </h3>
                </div>
                
                <div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                    <h3><center>&bull;</h3>
                </div>
                <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                    <h3>
                  Applied Nanoscience - Springer (SCI indexed)
                  </h3>
                 </div>
                 
                 <div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                    <h3><center>&bull;</h3>
                </div>
                <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                    <h3>
                  Materials Today - Elsevier (SCOPUS indexed)
                  </h3>
                 </div>
                 
                <div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                    <h3><center>&bull;</h3>
                </div>
                <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                    <h3>Journal of Physics -  (SCOPUS indexed)
                 </h3>
                </div>
                
                <!--<div class="col-lg-1 col-md-1 col-sm-2 col-xs-2">
                    <h3><center>&bull;</h3>
                </div>
                <div class="col-lg-11 col-md-11 col-sm-10 col-xs-10">
                    <h3>
                 Journal of Computational & Theoretical Nanoscience (SCOPUS indexed)
                 </h3>
                 </div>-->
                 
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <h4><center>                 <br><br><br>More Journals will be updated soon....<br><br></h4>
                 </div>
                                    

	 	     
         </div>
       
    <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
    

<?php
 mywebfoot();
 ?>