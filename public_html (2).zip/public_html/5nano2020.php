<?php
include 'main.php';
mywebhead();
?>

            
        <!--MAin content-->
             
                 <center>
                  <h2>5NANO2020 Conference</h2>
                 </center> 
	 	    
	      <div class="col-lg-offset-2 col-lg-6 col-md-offset-2 col-md-6 col-sm-12 col-xs-12 ">
         <h3> 5NANO2020 Programme Schedule</h3> 
         </div>
         
         <a href="5nano2020/5 NANO 2020 Program Schedule updated.pdf"  class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <h3><span class="glyphicon glyphicon-download-alt"></span> Download</h3>
        </a>
        
        
        <!--
	     <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
	         <h3><a href="5nano2020/Programme Schedule.jpg">Download</a></h3>
          </div>
          -->
	     <div class="col-lg-offset-2 col-lg-6 col-md-offset-2 col-md-6 col-sm-12 col-xs-12">
         <h3> 5NANO2020 Speakers </h3>
         </div>
	        <a href="5nano2020/Speakers.jpg" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <h3><span class="glyphicon glyphicon-download-alt"></span> Download</h3></a></h3>
          
          
          
	     <div class="col-lg-offset-2 col-lg-6 col-md-offset-2 col-md-6 col-sm-12 col-xs-12">
	         <h3> 5NANO2020 Parallel Session Schedule</h3>  
	     </div>
	     
	      <a href="5nano2020\5Nano2020ParallelSessionSchedule.pdf" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <h3><span class="glyphicon glyphicon-download-alt"></span> Download
          </h3></a>
	     
	     
	     
	     <div class="col-lg-offset-2 col-lg-6 col-md-offset-2 col-md-6 col-sm-12 col-xs-12">
	         <h3> 5NANO2020 Presentation Guidelines</h3>  
	     </div>
	     
	      <a href="5nano2020\5NANO2020 Virtual Conference Presentation.pdf" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <h3><span class="glyphicon glyphicon-download-alt"></span> Download
          </h3></a>
	     
	     
	     <div class="col-lg-offset-2 col-lg-6 col-md-offset-2 col-md-6 col-sm-12 col-xs-12">
	         <h3> 5NANO2020 Presentation Template</h3>  
	     </div>
	     
	      <a href="5nano2020\5NANO2020 PresentationTemplate.ppt" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <h3><span class="glyphicon glyphicon-download-alt"></span> Download
          </h3></a>
       
         <div class="col-lg-offset-2 col-lg-6 col-md-offset-2 col-md-6 col-sm-12 col-xs-12">
         <h3> 5NANO2020 Travel Grant Award
         </div>
	     
	      <a href="5nano2020/Travel Grant - 2020.pdf" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <h3><span class="glyphicon glyphicon-download-alt"></span> Download
          </h3></a> 
         
        
		 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;<br><br><br><br></div>          
        </div>
            
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
            
        
 <?php
 mywebfoot();
 ?>