<?php
include 'main.php';
mywebhead();
?>
        <style>
           
            
            
        </style>    
        <!--MAin content-->
        
                
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <h2>Conference Objectives</h2>
		           <h4>The IEEE 5NANO2023 International Conference is going to be dynamic and informative as it provides the premier interdisciplinary forum for researchers, practitioners and educators to present and discuss the most recent innovations, trends,  practical challenges encountered and the solutions adopted in the field of Nanotechnology.
		             <br><br>
		             </h4>
		             <h4 style="text-indent:0em;">
		              <center>The theme of the conference is about <br><font style="color:red">“Future Challenges and Advanced Innovations in Nanotechnology!”</font></center>
		           </h4>
                   <!--
                       <br>
                       
                         <a href="downloads/brochure5nano2023.jpg" target=_blank>
                        
                        <h4 style="text-indent:0em;"><center>Click here to download the CFP<br></center></h4> 
                         <center><img class="bg1 img2" src="/images/qr_brochure23.png" width=200 em height=200 em style="border-radius: 25px;"><center>
                         
                         </a>
                     
                       
                      <br>
                     -->  
                       <h4>
                     This is a 2-day event. During the conference you can participate in General Sessions, Poster Presentations, Workshops/Symposium, Meet-the-Professor Sessions, Oral Presentations and other interactive and informal exchanges. International symposiums, Panel Discussion and B2B meetings are organized based on the specific topics related to Nano Engineering and Technology.
                     </h4>
                        <h4>
                        Topics discussed will be the forthcoming use of Nano technology  in healthcare, Electronics,  Nano materials, Nano Technology tools, Robotics, Computational Techniques and the newest updates in Nano Engineering & Nano Technology.&nbsp;&nbsp;
                        </h4>
                        <h4>
                        We trust you will discover the Conference beneficial, enlightening and agreeable. We want to personally thank the speakers, moderators, and other volunteers who are participating in the planning of this conference.  Everyone’s energy is endless and everyone’s positive attitudes have amazed us throughout the year.
                         </h4>
           
                       
                              <h2>Call For Papers </h2>
                           <h4> 
                           
                           <center>IEEE Conference Record No. #55027<br><br>
                           
                           i) Call for in IEEE Photonics Society Official Website: <br>
                           
                    
                             
                             
                            <a href="https://www.photonicssociety.org/conferences/photonics-conference-calendar" target="_blank">
                                <img class="bg1 img2" src="/images/photonics_home_page.webp" width=70% height=40% em style="border-radius: 25px;">
                                
                                
                                
                                <br><br><br>
                                <!--<img class="bg1 img2" src="/images/qr-photonics.png"  width=200 em height=200 em style="border-radius: 25px;"-->
                            </a>
                            
                            
                            <br><br>
                            (ii) Call for in IEEE Conference Official Website: <br>
    
                             <a href="https://conferences.ieee.org/conferences_events/conferences/conferencedetails/55027" target="_blank"><br> Click here
                             
                            <!--<img class="bg1 img2" src="/images/ieee_home_page.webp" width=70% height=70% style="border-radius: 25px;">
                             
                               <br> <br> <br>
                                <!--<img class="bg1 img2" src="/images/qr-ieee-conf.png"  width=200 em height=200 em style="border-radius: 25px;"> -->
                             </a>
                             
                             <br><br>

                            </center>
                        
                           This conference provides a wonderful opportunity for you to enhance your knowledge about the newest interdisciplinary approaches in nanoscience and nanotechnology. Moreover, the conference offers a valuable platform to create new contacts in the field of nanoscience and nanotechnology, by providing valuable networking time for you to meet great personnel in the field. The main topics to be covered, but not limited to the following tracks:</h4>
                       </div>
                       <div  class="col-lg-8 col-md-8 col-sm-12 col-xs-12" > 
                       <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                            <h2>Scientific Sessions</h2>
                        </div>
                        
                         <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3><img src="regformnew.gif" alt="New" height="25" width="35">
                                AI-enhanced design, characterization, and manufacturing of
nanomaterials, nanodevices and nanotools</h3>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                
                                
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                Inverse design of nanophotonic structures
                                </h4>
                                </div>
                               
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                 <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Artificial Intelligence (AI)-enhanced design/additive of nanomaterials
                                    </h4>
                                </div>
                                
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Neural networks for prediction in nanophononics</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                                
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Neural networks for prediction in nanophotonic properties
                                </h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Neural networks for prediction in device performance
                                </h4>
                                </div>
                                
                            <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                              
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Artificial Intelligence (AI) enhanced nanomotors and active matters
                                </h4>
                            </div>
                                
                              <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>   
                             <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" >
                                <h4 class="h4l"> 
                                Application of convolution neural network in spectral analysis
                                 </h4>
                             </div>
                             
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                             <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Artificial Intelligence in nanotoxicology
                                </h4>
                            </div>





                             <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                 <h3>
                               <img src="regformnew.gif" alt="New" height="25" width="35">
                                 Nanotechnology-enhanced Artificial Intelligence hardware
and algorithm development   </h3>
                            </div>
                               
                               
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                             </div>  
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                            <h4 class="h4l"> 
                            Merging of machine learning and nanomaterials
                            </h4>
                            </div>
                            
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Nanoscale Electronic Synapses for Neuromorphic Computing
                                </h4>
                            </div>
                            
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Nanowire memristor as artificial synapse in random networks
                                </h4>
                            </div>
                            
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Nanomemories for neuromorphic computing</h4>
                                </div>
                                
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>    
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Photonic artificial neural networks</h4>
                                </div>
                            
                            
                            
                            <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"> 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Artificial intelligent accelerator using optoelectronic computing
                                    </h4>
                                </div>


                                
                                
                                
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                               <h3> <img src="regformnew.gif" alt="New" height="25" width="35">Scientific advancement and applications enhanced by  combining Artificial Intelligence (AI) and Nanotechnology</h3>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                              
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                Merging Artificial Intelligence (AI) and nanotechnology for single molecule science
                                 </h4>
                                </div>
                                
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                                 <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Artificial Intelligence (AI) and nanotechnology in biomedicine
                                    </h4>
                                </div>
                                
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                              </div>
                               <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanomaterials and artificial intelligence in anti-counterfeiting
                                </h4>
                                </div>
                                
                                
                            <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                             </div>
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    AI in chemistry studies
                                    </h4>
                            </div>
                                
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                             </div>  
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Intelligent Nanotechnology</h4>
                                </div>
                                
                                
                             <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                             </div>    
                            <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                    Merging Nanoscience and Artificial Intelligence
                                </h4>
                            </div>
                                
                       

                        <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                         <h3>Advanced Nanomaterials</h3>
                         </div>
                         
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"> 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                   <h4 class="h4l">	Nanoparticles Synthesis and applications</h4>
                                </div>
                                
                               <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanocomposites / Bionanocomposites Materials</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanofluids</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanostructured / nanoporous Materials and devices</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanostructured coatings, surfaces and membranes</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Carbon Nanostructures and devices</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Graphene</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Polymer Nanotechnology</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div> 	
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Soft Nanotechnology and Colloids</h4>
                                </div>
                                
                               
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3>Nanomaterials Fabrication, Characterization and Tools</h3>
                                </div> 	
                                
                                
                               <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div> 	
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Synthesis of Nanomaterials</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div> 	
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Sustainable Nanomanufacturing</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div> 	
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanoscale Materials Characterization</h4>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div> 	
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Modeling and Simulation at the Nanoscale</h4>
                                </div>
                                
                                
                                
                                
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3>Nanoscale Electronics </h3>
                                </div>
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                                <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Nano Electronics and Photonics</h4>
                                </div>
                               
                               <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Memory and logic devices, circuits and architecture for advanced CMOS technologies</h4>
                                </div>
                               
                               <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  >  
                                <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Beyond and extended CMOS devices</h4>
                                </div>
                               
                               <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Spin electronics</h4>
                                </div>
                               
                               
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Sensors based on emerging devices</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Quantum electronics</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Neuromorphic architectures</h4>
                                </div>
                                
                                
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                 <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                 	Interconnecting nanoscale objects</h4>
                                </div>
                                
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	3D approaches</h4>
                                </div>
                                </h4>
                                
                                
                                
                                
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3>Nanotech for Energy and Environment </h3>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Nanomaterials for Clean and Sustainable Technology</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Nanotechnology for Solar Energy Collection and Conversion</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">
                                     	Energy Storage and Novel Generation</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">Nanotech for Oil and Gas</h4>
                                </div>
                                 
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	NanoNuclear Materials</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Fuels Applications</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Renewable Energy Technologies</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Bio Sources for Materials and Fuels</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Green Chemistry and Materials</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Water Technologies</h4>
                                </div>
                                
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Hydrogen Energy Technologies</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Smart Grid</h4>
                                </div>
                                
                                   
                                
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3>Nanotech in Life Sciences and Medicine </h3>
                                </div>
 
                               <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Bionanomaterials and Tissues Engineering</h4>
                                </div>
                               
                                <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Biosensors, Diagnostics and Imaging</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Materials for Drug and Gene Delivery</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Biomarkers and Nanoparticles</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Cancer Diagnostics, Imaging and Treatment</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Drug Delivery and Therapeutics</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Cancer Nanotechnology</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Nano Robots</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	DNA nanotechnology</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l">	Nanotoxicity</h4>
                                </div>
                                
                                
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3>Nanotechnology Safety</h3>
                                </div>
                                
                                <h4 style="text-indent:0em; text-align:left;"> 
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	NanoToxicology</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Risk assessment and management</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Measurement of health risk</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Exposure scenarios</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Regulation and ethical impact</h4>
                                </div>
                                
                                
                                <div  class="col-lg-12 col-md-12 col-sm-12 col-xs-12" > 
                                <h3>Nano Applications</h3>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Food Technology</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Catalysis</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Military and Defence</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Aerospace and Vehicle Manufacturers</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Manufacturing and Construction</h4>
                                </div>
                                
                                 <div  class="col-lg-1 col-md-1 col-sm-2 col-xs-2"  > 
                               <h4 class="h4r"> &bull; </h4>
                                </div>
                                <div  class="col-lg-11 col-md-11 col-sm-10 col-xs-10" > 
                                <h4 class="h4l"> 	Textiles</h4>
                                </div>
                                
                                
                                
                                
                                
                               
                                
                           
                       
                        </div>
                			
                		<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
                			
                                 <center>
            			        	
                                 <h2>Announcements</h2>
                                
            			         <marquee width= "100%" height="500pt" behavior="scroll" direction="up" 
            			         scrollamount="10" style="border: 2px solid red;" onmouseover="this.stop();" onmouseout="this.start();" > 

                                 <h2>Publications</h2>
                                   <h4>
                                   Authors wishing to participate at the conference must register individually. Each selected paper requires at least one author to attend the conference for presentation. Papers not presented at the conference shall not be included in the Conference Publications 
                                   
<br><br>All accepted and presented papers will be submitted for inclusion in IEEE Xplore.

<br><br>Based on the scope and authors concern the extended version of high quality research articles will be recommended in any one of the following SCI & SCOPUS indexed Journals.</h4>


                                    <h3>
                                    <!--<br>&nbsp;&nbsp;&bull; Diamond & Related Materials -  Elsevier (SCI indexed)
                                    <br><br>&nbsp;&nbsp;&bull; 	International Journal of Hydrogen Energy -  Elsevier (SCI indexed)
                                    <br><br>&nbsp;&nbsp;&bull; Applied Nanoscience - Springer (SCI indexed)
                                    <br><br>&nbsp;&nbsp;&bull; Materials Today - Elsevier (SCOPUS indexed)
                                    <br><br>&nbsp;&nbsp;&bull; Journal of Physics -  (SCOPUS indexed)
                                    <br><br>&nbsp;&nbsp;&bull; Journal of Polytechnic (E- SCI)
                                    -->
                                    <br><br><br>More Journals will be updated soon....</br>
                                    </h3>
                                    

                                
                                    </br></b>
                			    </marquee>
                        </div>                			    
                
            </div>
            
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
            
          
        
 <?php
 mywebfoot();
 ?>