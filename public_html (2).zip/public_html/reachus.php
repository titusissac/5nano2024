<?php
include 'main.php';
mywebhead();
?>
        <!--MAin content-->
        <div class="container" style="height:600px;">
                  
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <center>
                  <h2>Reaching Us</h2>
                 </center> 
              </div>
	 	    
	 	        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right"> &rarr;
                    </h4>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                    <h4 style="text-indent:0em;"> 
                    VISAT Engineering College campus is located in the scenic parts of the Ernakulam district,
along the Western Ghats, offering spectacular views of the mighty hill ranges.

The college campus is located at Mutholapuram Post, Elanji, Ernakulam,
Kerala, India
                </h4>
                </div>
                
                
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">
                         
    Nearest airport - 56 km, Cochin International Airport <br>

                    </h4>
                </div>
                
                
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">
 
Nearest airport - 194 km, Trivandrum International Airport<br>

                    </h4>
                </div>
                
                
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">
 

Nearest railway station - 34 km, Kottayam Railway Station<br>

                    </h4>
                </div>
              
              
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">

Nearest railway station - 41 km, Ernakulam Railway Station<br>

                    </h4>
                </div>
              
              
              
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">

Nearest railway station - 47 km, Aluva Railway Station (Nearest to Cochin Airport)<br>

                    </h4>
                </div>
              
              
                
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">

Nearest bus stand – 34 km, Kottayam Bustand<br>

                    </h4>
                </div>
              
              
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">

Nearest bus stand – 41 km, Ernakulam Bustand<br>

                    </h4>
                </div>
                
                
                 
              <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                    <h4 style="text-indent:0em; text-align:right">
                         &rarr;
                    </h4>
                </div>
                
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-align:right">
                    <h4 style="text-indent:0em;">

Nearest bus stand – 6 km, Monipally Bustand<br>
                    </h4>
                </div>
              
                <br><br>&nbsp;
		           
            </div>
            
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
        
        
        </div>    

        
        


 <?php
 mywebfoot();
 ?>