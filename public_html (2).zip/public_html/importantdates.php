<?php
include 'main.php';
mywebhead();
?>

        <!--MAin content-->
                              			    
               
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   
                   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <h2><center>Important Dates</center><br></h2> 
              <!-- <h3><center>5NANO2020 Announcement: Rescheduled Dates Have Now Been Announced <br><br></h3></center>
	 	       </div>-->
	 	       
	 	       <div class="col-lg-offset-1 col-lg-4 col-md-offset-1 col-md-4 col-sm-12 col-xs-12">
	 	       <h3><center>30<sup>th</sup> December  2022 </h3>
	 	       </div>
	 	       <div class="col-lg-1 col-md-1 hidden-sm hidden-xs">
	 	           <h3>:</h3></div>
	 	       <div class="col-lg-6 col-md-6 hidden-sm hidden-xs">
	 	       <h3 style="color:#000000;"> Final deadline for submission of full papers<br><br></h3>
	 	       </div>
	 	       <div class="hidden-lg hidden-lg col-sm-12 col-xs-12">
	 	       <h3 style="color:#000000; text-align:center"> Final deadline for submission of full papers<br><br><br><br></h3>
	 	       </div>
	 	       
	 	       
	 	       <div class="col-lg-offset-1 col-lg-4 col-md-offset-1 col-md-4 col-sm-12 col-xs-12">
	 	        
	 	         <h3 ><center>30<sup>th</sup> January 2023</h3>
	 	       </div>
	 	       <div class="col-lg-1 col-md-1 hidden-sm hidden-xs">
	 	           <h3>:</h3></div>
    		   <div class="col-lg-6 col-md-6 hidden-sm hidden-xs">
    		    <h3 style="color:#000000;">Acceptance / Rejection notification<br><br></h3>
    		   </div>
    		   <div class="hidden-lg hidden-lg col-sm-12 col-xs-12">
	 	       <h3 style="color:#000000; text-align:center"> Acceptance / Rejection notification<br><br><br><br></h3>
	 	       </div>
    		   
    		    	
    		    <div class="col-lg-offset-1 col-lg-4 col-md-offset-1 col-md-4 col-sm-12 col-xs-12">
    		  <h3><center>25<sup>th</sup> Feburary 2023</h3> 
    		   </div>
    		   <div class="col-lg-1 col-md-1 hidden-sm hidden-xs">
    		       <h3>:</h3></div>
    		   <div class="col-lg-6 col-md-6 hidden-sm hidden-xs">
    		    <h3 style="color:#000000;">Final Paper Submission and Registration<br><br></h3>
    		    
    		    </div>
    		    <div class="hidden-lg hidden-lg col-sm-12 col-xs-12">
    		    <h3 style="color:#000000; text-align:center">Final Paper Submission and Registration<br><br><br><br></h3>
    		    
    		    </div>
    		    
    		    <div class="col-lg-offset-1 col-lg-4 col-md-offset-1 col-md-4 col-sm-12 col-xs-12">
    		    <h3><center>27<sup>th</sup> & 28<sup>th</sup> April 2023</h3> 
    		    </div>
    		    <div class="col-lg-1 col-md-1 hidden-sm hidden-xs">
    		        <h3>:</h3></div>
    		    <div class="col-lg-5 col-md-5 hidden-sm hidden-xs">
    		     <h3 style="color:#000000;">Conference Open</h3><br><br></h3>
    		     <br><br>
                </div>
                
                 <div class="hidden-lg hidden-lg col-sm-12 col-xs-12">
    		    <h3 style="color:#000000; text-align:center">Conference Open<br><br><br><br></h3>
    		    
    		    </div>
    		    
                
    	
                
	 	       
            </div>
            </div>
            
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
            
        </div>  
        

 <?php
 mywebfoot();
 ?>