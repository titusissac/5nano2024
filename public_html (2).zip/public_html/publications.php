<?php
include 'main.php';
mywebhead();
?>

            
        <!--MAin content-->
             
                 <center>
                  <h2>Announcement</h2>
                 </center> 
	 	    
	 	    
<h3>Publications:</h3>
<h4>Authors wishing to participate at the conference must register individually. Each selected paper requires at least one author to attend the conference for presentation. Papers not actually presented at the conference shall not be included in the Conference Publications.
<br><br>All accepted and presented papers will be submitted for inclusion in IEEE Xplore.

<br><br>Based on the scope and authors concern the extended version of high quality research articles will be recommended to SCI & SCOPUS indexed Journals.
<br><br>


<br><br>
<br>
<br><br><br><br><br>
</h4>




		           
            </div>
            
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
            
        
 <?php
 mywebfoot();
 ?>