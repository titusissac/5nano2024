<?php
include 'main.php';
mywebhead();
?>
            
        <!--MAin content-->
              
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                 <h2> <center>Organizing Committee</center> <br></h2> 
                 </div>
                 
	 	      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <h3><center>Chief Patron</h3>
               <h4 style="text-indent:0em;"><b><center>Shri. Raju Kurian</b><br> Chairman, <br> VISAT Engineering College &amp; UNISIS Group of Companies</h4>
               </div>
           
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
             <h3><center>Patron</h3>
              <h4 style="text-indent:0em;"><b><center> Wing Commander Pramod Nair (Retd)</b><br> Director,<br> VISAT Engineering College.</h4>
             
             
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <h3><center>Conference General Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Dr.Anoop K J,</b><br> Principal,<br> VISAT Engineering College.</h4>
            </div>
                
                  
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <h3><center>Conference Co-General Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Subin P S,</b><br> Registrar,<br> VISAT Engineering College.</h4>
            </div>
             
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h3><center>Conference Organizing Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Lt.Dr.T.D.Subash,</b><br> Global Strategy Representative for India, <br>IEEE Photonics Society, USA.
</h4>
            </div>
    	 	 
	     	    
	     	 <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
	 	        <h3><center>Publication Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Dr.Ajayan J ,</b><br> Associate. Prof/EEE,<br> SR University, Warangal,India.</h4>
            </div>
                
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Travel Grant Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Divya Nair,</b><br> Asst. Prof /CSE, <br>VISAT Engineering College.</h4>
            </div>
          
          
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Keynote Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Eldo K Paul,</b><br> HoD /CSE, <br>VISAT Engineering College.</h4>
            </div>
            
            
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Publicity Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Sheeja Bhaskar</b><br> HoD / Science & Humanities, <br>VISAT Engineering College.</h4>
            </div>
            
             <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Finance Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Shyama M</b><br> HoD / ECE, <br>VISAT Engineering College.</h4>
            </div>
            
            
             <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Local Arrangement Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Shyama M</b><br> HoD / ECE, <br>VISAT Engineering College.</h4>
            </div>
            
            
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Program Committee Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Timi Thomas</b><br> HoD / CE, <br>VISAT Engineering College.</h4>
            </div>
            
            
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <h3><center>Award Chair</h3>
                <h4 style="text-indent:0em;"><b><center>Prof. Ramesh M</b><br> HoD / ME, <br>VISAT Engineering College.</h4>
            </div>
            
            
            
            	 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <h3><center>Advisory Committee</h3>
                     <h4 style="text-indent:0em;"><b><center>   Dr. Abdel-badeeh M. Salem,</b><br> Ain Shams University, Cairo, Egypt.</h4>
                     <h4 style="text-indent:0em;"><b><center>   Dr. Deepa Venkitesh,</b><br> Indian Institute of Technology, Madras, India.</h4>
                     
                     <h4 style="text-indent:0em;"><b><center>   Dr. Er Meng Joo,</b><br> Nangyang Technological University, Singapore.</h4>
                     <h4 style="text-indent:0em;"><b><center>   Dr. Gopikrishna Saramekala,</b><br> National Institute of Technology, Calicut, India.</h4>
                      <h4 style="text-indent:0em;"><b><center>   Dr. James E Morris,</b><br> Portland State University, USA.</h4>
                     <h4 style="text-indent:0em;"><b><center>   Dr. K. Chandrasekaran,</b><br> National Institute of Technology, Raipur, India.</h4>
                     <h4 style="text-indent:0em;"><b><center>  Dr. K.Navin Sam,</b><br> National Institute of Technology, Puducherry, India.</h4>
                     
                     <h4 style="text-indent:0em;"><b><center>  Dr. K. Senthil Kumar,</b><br> National Institute of Technology, Meghalaya, India.</h4>
                     <h4 style="text-indent:0em;"><b><center>  Dr. Llyods Raja,</b><br> National Institute of Technology, Patna, India.</h4>
                     
                     <h4 style="text-indent:0em;"><b><center>   Dr. Manpreet Singh Manna</b><br> Sant Longowal Institute of Engineering & Technology, Punjab, India. <br> Former Director, AICTE.</h4>
                     
                     <h4 style="text-indent:0em;"><b><center>   Dr. Magdy A. Bayoumi,</b><br> University of Louisiana at Lafayette, USA.</h4>
                     <h4 style="text-indent:0em;"><b><center>    Dr. Mamun Bin Ibne Reaz,</b><br> University of Kebangsaan, Malaysia.</h4>
                     <h4 style="text-indent:0em;"><b><center>    Dr. Marcin Paprzycki,</b><br> Polish Academy of Sciences, Poland.</h4>
                     <h4 style="text-indent:0em;"><b><center>    Dr. Muhammad Sarfraz,</b><br> Kuwait University, Kuwait.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. R.Balasubramanian,</b><br> Indian Institute of Technology, Roorkee, India.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Rajesh Joseph Abraham,</b><br> Indian Institute of Space Science &amp; Technology, Trivandrum, India.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Rajibkar,</b><br> National Institute of Technology, Durgapur, India.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Revathy Padmanabhan,</b><br> Indian Institute of Technology, Palakkad, India.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Sandeep Raj,</b><br> Indian Institute of Technology, Bhagalpur, India.</h4>
                    
                    <h4 style="text-indent:0em;"><b><center>    Dr. S.Moorthi,</b><br> National Institute of Technology, Trichy, India.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Srinivas Talabattula,</b><br> National Institute of Science, Karnataka, India.</h4>
                    
                    
                    <h4 style="text-indent:0em;"><b><center>    Dr. Sreejith.S,</b><br> National Institute of Technology, Silcher, India.</h4>
                     <h4 style="text-indent:0em;"><b><center>    Dr. Satyabrata Jit S,</b><br> Indian Institute of Technology, Bhuvaneshwar, India.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Sheikh Mohamed,</b><br> Toyo University, Japan.</h4>
                    
                    <h4 style="text-indent:0em;"><b><center>    Dr. Shuai Li,</b><br> Hong Kong Polytechnic University, Hong Kong.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Sisil Kumarawadu,</b><br> University of Moratuwa, Srilanka.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Takashi Hikihara,</b><br> Kyoto Institute of Technology, Japan.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Vishal kumar,</b><br> Indian Institute of Technology, Roorkee, India.</h4>
                    
                    <h4 style="text-indent:0em;"><b><center>    Dr. Walid Tawfik,</b><br> Cairo University, Egypt.</h4>
                    <h4 style="text-indent:0em;"><b><center>    Dr. Wladyslaw Grabinski,</b><br> Geneva Modeling Center Commugny, Switzerland.</h4>
                    
                    <h4 style="text-indent:0em;" ><b><center>    Dr. Xavier Fernando,</b><br> Ryerson University, Canada</h4>
                 </div>    
                 
           
           
           
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h3><center>Technical Program Committee</h3>
<h4 style="text-indent:0em;"><b><center>Dr. Naresh Chand,</b><br> Associate Vice President, IEEE Photonics Society, USA
<!--<h4 style="text-indent:0em;"><b><center>Dr. Arunachala Perumal,</b><br> Chair, IEEE Photonics Society Madras Chapter</h4>
<h4 style="text-indent:0em;"><b><center>Dr. Llyods Raja,</b><br> National Institute of Technology, Patna, India</h4>
<h4 style="text-indent:0em;"><b><center>Dr. T. Senthil Siva Subramanian,</b><br> Sharda Group of Institutions, Agra, India</h4>-->
<h4 style="text-indent:0em;"><b><center>Dr. J. Ajayan,</b><br> SR University, Warangal, India</h4>

<h4 style="text-indent:0em;"><b><center>Dr. Niloy K. Dutta,</b><br> University of Connecticut, Storrs, USA</h4>

<h4 style="text-indent:0em;"><b><center>Dr. Srinivas Talabattula
 
</b><br> Indian Institute of Science(IISC) Bengaluru, Karnataka, India</h4>

<h4 style="text-indent:0em;"><b><center>Prof. Gabriella Cincotti
</b><br>  University Roma Tre, Rome, Italy</h4>

<h4 style="text-indent:0em;"><b><center>Prof. Ray-Hua Horng

</b><br> National Chiao Tung  University, Taiwan
</h4>

            </div>
	 	    
        
         
       
    <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
       </div>
</div>
   <?php
 mywebfoot();
 ?>