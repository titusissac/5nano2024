<?php
include 'main.php';
mywebhead();
?>


        <!--MAin content-->
         <div class="container" style="height:600px;">      
                 <center>
                  <h2> Visa Process<br> <br> </h2>
                 </center> 
	 	    
	 	    <h3>  <center><br>    <a href="https://indianvisaonline.gov.in/evisa/" target="_blank">Click here to apply for Visa  <br>
	 	    <img class="bg1 img2" width=150em src="./images/qr-visa.png" style="border-radius:5pt">
	 	    
	 	    </center><br><br><br><br> </h3>

              
            </div>
            
        <!--white space-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> &nbsp;</div>
         </div>   
           
        
 <?php
 mywebfoot();
 ?>